SETOR: PACIENTES - Hospital DC
Data de criação: 2026-06-08 22:36:16
Responsável: Administração de TI
Descrição: Diretório para armazenamento de dados de pacientes cadastrados.
