SETOR: PRONTUÁRIOS - Hospital DC
Data de criação: 2026-06-08 22:36:16
Responsável: Administração de TI
Descrição: Diretório para prontuários eletrônicos dos pacientes.
ACESSO RESTRITO - Somente médicos autorizados.
